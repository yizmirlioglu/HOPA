# Incremantally Solving the n-Queens Problem

In this example, we calculate solutions for the n-Queens problem for different
board sizes, which can be given as a list of intervals on the command line.

## Example Calls

    clingo incqueens.lp incqueens-py.lp -c calls="list((1,1),(3,5),(8,9))"
    clingo incqueens.lp incqueens-lua.lp -c calls="list((1,1),(3,5),(8,9))"

